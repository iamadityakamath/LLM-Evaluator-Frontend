'use client'

import { useState, useMemo } from 'react'
import { AppShell } from '@/components/evalforge/app-shell'
import { useDatasets, usePrompts, useApiKey, useEvaluations } from '@/hooks/use-evalforge-storage'
import { MODELS, EVALUATION_TYPES, EvaluationType } from '@/lib/evalforge-types'
import { cn } from '@/lib/utils'
import { 
  Play, 
  Database, 
  FileText, 
  Key, 
  Eye, 
  EyeOff, 
  AlertCircle,
  CheckCircle2,
  Loader2
} from 'lucide-react'

export default function HomePage() {
  const { datasets, isLoaded: datasetsLoaded } = useDatasets()
  const { prompts, isLoaded: promptsLoaded } = usePrompts()
  const { apiKey, setApiKey, isLoaded: apiKeyLoaded } = useApiKey()
  const { addEvaluation } = useEvaluations()

  const [selectedDataset, setSelectedDataset] = useState('')
  const [selectedModel, setSelectedModel] = useState('')
  const [customModel, setCustomModel] = useState('')
  const [selectedPrompt, setSelectedPrompt] = useState('')
  const [evaluationType, setEvaluationType] = useState<EvaluationType>('accuracy')
  const [showApiKey, setShowApiKey] = useState(false)
  const [isRunning, setIsRunning] = useState(false)
  const [runSuccess, setRunSuccess] = useState(false)

  const isLoaded = datasetsLoaded && promptsLoaded && apiKeyLoaded

  const selectedModelInfo = useMemo(() => {
    return MODELS.find(m => m.value === selectedModel)
  }, [selectedModel])

  const isValid = useMemo(() => {
    const hasDataset = selectedDataset !== ''
    const hasModel = selectedModel !== '' && (selectedModel !== 'custom' || customModel !== '')
    const hasPrompt = selectedPrompt !== ''
    const hasApiKey = apiKey !== ''
    return hasDataset && hasModel && hasPrompt && hasApiKey
  }, [selectedDataset, selectedModel, customModel, selectedPrompt, apiKey])

  const handleRunEvaluation = () => {
    if (!isValid) return

    setIsRunning(true)
    setRunSuccess(false)

    const dataset = datasets.find(d => d.id === selectedDataset)
    const prompt = prompts.find(p => p.id === selectedPrompt)
    const model = selectedModel === 'custom' ? customModel : selectedModel

    // Simulate running evaluation
    setTimeout(() => {
      addEvaluation({
        datasetId: selectedDataset,
        datasetName: dataset?.name || 'Unknown',
        model,
        promptId: selectedPrompt,
        promptName: prompt?.name || 'Unknown',
        evaluationType,
        status: 'pending',
      })
      setIsRunning(false)
      setRunSuccess(true)
      setTimeout(() => setRunSuccess(false), 3000)
    }, 1500)
  }

  if (!isLoaded) {
    return (
      <AppShell title="Evaluation Setup" description="Configure and run model evaluations">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell title="Evaluation Setup" description="Configure and run model evaluations">
      <div className="grid gap-6 lg:grid-cols-2">
        {/* Dataset Selector */}
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <Database className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Dataset</h2>
              <p className="text-xs text-muted-foreground">Select evaluation dataset</p>
            </div>
          </div>
          <select
            value={selectedDataset}
            onChange={(e) => setSelectedDataset(e.target.value)}
            className="w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="">Select a dataset...</option>
            {datasets.map((dataset) => (
              <option key={dataset.id} value={dataset.id}>
                {dataset.name} ({dataset.recordCount} records)
              </option>
            ))}
          </select>
          {datasets.length === 0 && (
            <p className="mt-2 text-xs text-amber-500">
              No datasets available. Upload one in the Data page.
            </p>
          )}
        </div>

        {/* Prompt Selector */}
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <FileText className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Prompt</h2>
              <p className="text-xs text-muted-foreground">Select evaluation prompt</p>
            </div>
          </div>
          <select
            value={selectedPrompt}
            onChange={(e) => setSelectedPrompt(e.target.value)}
            className="w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="">Select a prompt...</option>
            {prompts.map((prompt) => (
              <option key={prompt.id} value={prompt.id}>
                {prompt.name}
              </option>
            ))}
          </select>
          {prompts.length === 0 && (
            <p className="mt-2 text-xs text-amber-500">
              No prompts available. Create one in the Prompts page.
            </p>
          )}
        </div>

        {/* Model Selector */}
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <span className="font-mono text-sm font-bold text-accent">AI</span>
            </div>
            <div>
              <h2 className="font-semibold text-foreground">Model</h2>
              <p className="text-xs text-muted-foreground">Select language model</p>
            </div>
          </div>
          <select
            value={selectedModel}
            onChange={(e) => setSelectedModel(e.target.value)}
            className="w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
          >
            <option value="">Select a model...</option>
            {MODELS.map((model) => (
              <option key={model.value} value={model.value}>
                {model.label} ({model.provider})
              </option>
            ))}
          </select>
          {selectedModel === 'custom' && (
            <input
              type="text"
              value={customModel}
              onChange={(e) => setCustomModel(e.target.value)}
              placeholder="Enter custom model identifier..."
              className="mt-3 w-full rounded-lg border border-border bg-input px-4 py-3 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
          )}
        </div>

        {/* API Key */}
        <div className="rounded-xl border border-border bg-card p-6">
          <div className="mb-4 flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/10">
              <Key className="h-5 w-5 text-accent" />
            </div>
            <div>
              <h2 className="font-semibold text-foreground">API Key</h2>
              <p className="text-xs text-muted-foreground">
                {selectedModelInfo ? `${selectedModelInfo.provider} API Key` : 'Provider API Key'}
              </p>
            </div>
          </div>
          <div className="relative">
            <input
              type={showApiKey ? 'text' : 'password'}
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder="Enter your API key..."
              className="w-full rounded-lg border border-border bg-input px-4 py-3 pr-12 font-mono text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
            />
            <button
              type="button"
              onClick={() => setShowApiKey(!showApiKey)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            >
              {showApiKey ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
            </button>
          </div>
        </div>

        {/* Evaluation Type */}
        <div className="rounded-xl border border-border bg-card p-6 lg:col-span-2">
          <h2 className="mb-4 font-semibold text-foreground">Evaluation Type</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {EVALUATION_TYPES.map((type) => (
              <button
                key={type.value}
                onClick={() => setEvaluationType(type.value)}
                className={cn(
                  'rounded-lg border p-4 text-left transition-all',
                  evaluationType === type.value
                    ? 'border-primary bg-primary/10'
                    : 'border-border bg-secondary/30 hover:border-muted-foreground'
                )}
              >
                <p className={cn(
                  'font-medium',
                  evaluationType === type.value ? 'text-primary' : 'text-foreground'
                )}>
                  {type.label}
                </p>
                <p className="mt-1 text-xs text-muted-foreground">{type.description}</p>
              </button>
            ))}
          </div>
        </div>

        {/* Run Button */}
        <div className="lg:col-span-2">
          <button
            onClick={handleRunEvaluation}
            disabled={!isValid || isRunning}
            className={cn(
              'flex w-full items-center justify-center gap-3 rounded-xl px-8 py-4 font-semibold transition-all',
              isValid && !isRunning
                ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                : 'cursor-not-allowed bg-secondary text-muted-foreground'
            )}
          >
            {isRunning ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin" />
                Running Evaluation...
              </>
            ) : runSuccess ? (
              <>
                <CheckCircle2 className="h-5 w-5" />
                Evaluation Started!
              </>
            ) : (
              <>
                <Play className="h-5 w-5" />
                Run Evaluation
              </>
            )}
          </button>
          {!isValid && !isRunning && (
            <div className="mt-3 flex items-center justify-center gap-2 text-sm text-amber-500">
              <AlertCircle className="h-4 w-4" />
              Please fill in all required fields
            </div>
          )}
        </div>
      </div>
    </AppShell>
  )
}
