'use client'

import { useState, useRef } from 'react'
import { AppShell } from '@/components/evalforge/app-shell'
import { EmptyState } from '@/components/evalforge/empty-state'
import { useDatasets } from '@/hooks/use-evalforge-storage'
import { cn } from '@/lib/utils'
import { 
  Upload, 
  Database, 
  Trash2, 
  ChevronDown,
  ChevronUp,
  X,
  Save,
  Loader2,
  FileJson
} from 'lucide-react'

interface UploadPreview {
  records: Record<string, unknown>[]
  filename: string
}

export default function DataPage() {
  const { datasets, addDataset, deleteDataset, isLoaded } = useDatasets()
  const fileInputRef = useRef<HTMLInputElement>(null)
  
  const [uploadPreview, setUploadPreview] = useState<UploadPreview | null>(null)
  const [datasetName, setDatasetName] = useState('')
  const [expandedDataset, setExpandedDataset] = useState<string | null>(null)
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null)
  const [uploadError, setUploadError] = useState<string | null>(null)

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setUploadError(null)

    try {
      const text = await file.text()
      const data = JSON.parse(text)
      
      // Ensure it's an array
      const records = Array.isArray(data) ? data : [data]
      
      setUploadPreview({
        records,
        filename: file.name.replace('.json', ''),
      })
      setDatasetName(file.name.replace('.json', ''))
    } catch {
      setUploadError('Invalid JSON file. Please upload a valid JSON array.')
    }

    // Reset file input
    if (fileInputRef.current) {
      fileInputRef.current.value = ''
    }
  }

  const handleSaveDataset = () => {
    if (!uploadPreview || !datasetName.trim()) return

    addDataset(datasetName.trim(), uploadPreview.records)
    setUploadPreview(null)
    setDatasetName('')
  }

  const handleCancelUpload = () => {
    setUploadPreview(null)
    setDatasetName('')
    setUploadError(null)
  }

  const handleDelete = (id: string) => {
    deleteDataset(id)
    setDeleteConfirmId(null)
    if (expandedDataset === id) {
      setExpandedDataset(null)
    }
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    })
  }

  if (!isLoaded) {
    return (
      <AppShell title="Data" description="Manage your evaluation datasets">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </AppShell>
    )
  }

  return (
    <AppShell title="Data" description="Manage your evaluation datasets">
      {/* Upload Button */}
      <div className="mb-6 flex justify-end">
        <input
          ref={fileInputRef}
          type="file"
          accept=".json"
          onChange={handleFileSelect}
          className="hidden"
        />
        <button
          onClick={() => fileInputRef.current?.click()}
          className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-colors hover:bg-primary/90"
        >
          <Upload className="h-4 w-4" />
          Upload JSON
        </button>
      </div>

      {/* Upload Error */}
      {uploadError && (
        <div className="mb-6 rounded-lg border border-destructive/50 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {uploadError}
        </div>
      )}

      {/* Upload Preview Modal */}
      {uploadPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 backdrop-blur-sm p-4">
          <div className="w-full max-w-3xl rounded-xl border border-border bg-card p-6 shadow-2xl">
            <div className="mb-6 flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <FileJson className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h2 className="text-xl font-semibold text-foreground">Upload Dataset</h2>
                  <p className="text-sm text-muted-foreground">
                    {uploadPreview.records.length} records found
                  </p>
                </div>
              </div>
              <button
                onClick={handleCancelUpload}
                className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {/* Dataset Name */}
            <div className="mb-4">
              <label className="mb-1.5 block text-sm font-medium text-foreground">
                Dataset Name
              </label>
              <input
                type="text"
                value={datasetName}
                onChange={(e) => setDatasetName(e.target.value)}
                placeholder="Enter dataset name..."
                className="w-full rounded-lg border border-border bg-input px-4 py-3 text-sm text-foreground placeholder:text-muted-foreground focus:border-primary focus:outline-none focus:ring-1 focus:ring-primary"
              />
            </div>

            {/* Preview Table */}
            <div className="mb-6">
              <p className="mb-2 text-sm font-medium text-foreground">Preview (first 3 records)</p>
              <div className="overflow-x-auto rounded-lg border border-border">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-border bg-secondary/50">
                      {Object.keys(uploadPreview.records[0] || {}).slice(0, 5).map((key) => (
                        <th
                          key={key}
                          className="px-4 py-2.5 text-left font-mono text-xs font-medium text-muted-foreground"
                        >
                          {key}
                        </th>
                      ))}
                      {Object.keys(uploadPreview.records[0] || {}).length > 5 && (
                        <th className="px-4 py-2.5 text-left font-mono text-xs font-medium text-muted-foreground">
                          ...
                        </th>
                      )}
                    </tr>
                  </thead>
                  <tbody>
                    {uploadPreview.records.slice(0, 3).map((record, i) => (
                      <tr key={i} className="border-b border-border last:border-0">
                        {Object.values(record).slice(0, 5).map((value, j) => (
                          <td
                            key={j}
                            className="px-4 py-2.5 font-mono text-xs text-foreground"
                          >
                            <span className="line-clamp-1">
                              {typeof value === 'object' 
                                ? JSON.stringify(value) 
                                : String(value)}
                            </span>
                          </td>
                        ))}
                        {Object.keys(record).length > 5 && (
                          <td className="px-4 py-2.5 font-mono text-xs text-muted-foreground">
                            ...
                          </td>
                        )}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="flex justify-end gap-3">
              <button
                onClick={handleCancelUpload}
                className="rounded-lg px-4 py-2.5 text-sm font-medium text-muted-foreground hover:text-foreground"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveDataset}
                disabled={!datasetName.trim()}
                className={cn(
                  'flex items-center gap-2 rounded-lg px-4 py-2.5 text-sm font-medium transition-colors',
                  datasetName.trim()
                    ? 'bg-primary text-primary-foreground hover:bg-primary/90'
                    : 'cursor-not-allowed bg-secondary text-muted-foreground'
                )}
              >
                <Save className="h-4 w-4" />
                Save Dataset
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Datasets List */}
      {datasets.length > 0 ? (
        <div className="space-y-4">
          {datasets.map((dataset) => (
            <div
              key={dataset.id}
              className="rounded-xl border border-border bg-card overflow-hidden"
            >
              {/* Dataset Header */}
              <div className="flex items-center justify-between p-5">
                <button
                  onClick={() => setExpandedDataset(
                    expandedDataset === dataset.id ? null : dataset.id
                  )}
                  className="flex flex-1 items-center gap-4 text-left"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                    <Database className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-foreground">{dataset.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      {dataset.recordCount} records • Uploaded {formatDate(dataset.uploadedAt)}
                    </p>
                  </div>
                </button>
                <div className="flex items-center gap-2">
                  {deleteConfirmId === dataset.id ? (
                    <>
                      <button
                        onClick={() => setDeleteConfirmId(null)}
                        className="rounded-lg px-3 py-2 text-xs font-medium text-muted-foreground hover:text-foreground"
                      >
                        Cancel
                      </button>
                      <button
                        onClick={() => handleDelete(dataset.id)}
                        className="rounded-lg bg-destructive px-3 py-2 text-xs font-medium text-destructive-foreground"
                      >
                        Confirm Delete
                      </button>
                    </>
                  ) : (
                    <button
                      onClick={() => setDeleteConfirmId(dataset.id)}
                      className="rounded-lg p-2 text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      title="Delete"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  )}
                  <button
                    onClick={() => setExpandedDataset(
                      expandedDataset === dataset.id ? null : dataset.id
                    )}
                    className="rounded-lg p-2 text-muted-foreground hover:bg-secondary hover:text-foreground"
                  >
                    {expandedDataset === dataset.id ? (
                      <ChevronUp className="h-4 w-4" />
                    ) : (
                      <ChevronDown className="h-4 w-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Expanded Preview */}
              {expandedDataset === dataset.id && (
                <div className="border-t border-border bg-secondary/20 p-5">
                  <p className="mb-3 text-sm font-medium text-muted-foreground">
                    Preview (up to 10 rows)
                  </p>
                  <div className="overflow-x-auto rounded-lg border border-border">
                    <table className="w-full">
                      <thead>
                        <tr className="border-b border-border bg-secondary/50">
                          {Object.keys(dataset.records[0] || {}).slice(0, 6).map((key) => (
                            <th
                              key={key}
                              className="px-4 py-2.5 text-left font-mono text-xs font-medium text-muted-foreground"
                            >
                              {key}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {dataset.records.slice(0, 10).map((record, i) => (
                          <tr key={i} className="border-b border-border last:border-0">
                            {Object.values(record).slice(0, 6).map((value, j) => (
                              <td
                                key={j}
                                className="px-4 py-2.5 font-mono text-xs text-foreground"
                              >
                                <span className="line-clamp-2 max-w-[200px]">
                                  {typeof value === 'object' 
                                    ? JSON.stringify(value) 
                                    : String(value)}
                                </span>
                              </td>
                            ))}
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              )}
            </div>
          ))}
        </div>
      ) : (
        <EmptyState
          icon={Database}
          title="No datasets yet"
          description="Upload your first JSON dataset to start evaluating models. Your data will be stored locally in your browser."
          action={
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex items-center gap-2 rounded-lg bg-primary px-4 py-2.5 font-medium text-primary-foreground transition-colors hover:bg-primary/90"
            >
              <Upload className="h-4 w-4" />
              Upload First Dataset
            </button>
          }
        />
      )}
    </AppShell>
  )
}
